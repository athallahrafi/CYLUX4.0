const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: process.env.PGPORT || 5432,
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || 'postgres',
  database: process.env.PGDATABASE || 'chemecar',
});

pool.on('connect', () => {
  console.log('[PostgreSQL] Terhubung ke database');
});

pool.on('error', (err) => {
  console.error('[PostgreSQL] Error tak terduga pada client idle', err);
});

module.exports = pool;
